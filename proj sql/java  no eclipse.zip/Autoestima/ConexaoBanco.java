package connector;

import java.sql.Connection;
import java.sql.DriverManager;
public class ConexaoBanco {


private static String DATABASE_URL = "jdbc:mysql://localhost:3306/Autoestima";

private static String USER = "root";

private static String PASSWORD = "172016";

public static  Connection createConnection() throws Exception{
	Class.forName("com.mysql.cj.jdbc.Driver");
	
	Connection conn = DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
return conn;
}
public static void main(String[]args) throws Exception {
	Connection conn = createConnection();
	
	if(conn != null) {
		System.out.println("conex�o  com sucesso");
		
	}else {System.out.println("erro em conex�o");
	}
}
}
