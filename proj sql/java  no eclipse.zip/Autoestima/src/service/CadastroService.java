package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;
import connector.ConexaoBanco;
import model.Cadastro;


public class CadastroService {
	
	public void save() {
		Scanner sc = new Scanner(System.in);
		Cadastro cadastro = new Cadastro();
		
		
		
		System.out.println("digite seu Nome");
		cadastro.setNome( sc.next());
		
		System.out.println("digite seu Telefone");
		cadastro.setTelefone(sc.nextInt());
		
		System.out.println("digite seu Email");
		cadastro.setEmail(sc.next());
		
		System.out.println("digite seu Rg");
		cadastro.setRg(sc.nextInt());
		
		System.out.println("digite  Data da compra");
		cadastro.setDataCompra(sc.next());
		
		System.out.println("digite  Tipo de compra");
		cadastro.setTipocompra(sc.next());
		
		System.out.println("digite seu cpf");
		cadastro.setCpf (sc.nextInt());

		System.out.println("digite seu estado");
		cadastro.setEstado(sc.next());
		
		System.out.println("digite seu cidade");
		cadastro.setCidade(sc.next());
		
		
		String sql = "INSERT INTO Cadastro(nome, telefone, email, rg, dataCompra, tipoCompra, cpf, estado, cidade)VALUES(?,?,?,?,?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConexaoBanco.createConnection();
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1,cadastro.getNome());
			pstm.setInt(2,cadastro.getTelefone());
			pstm.setString(3,cadastro.getEmail());
			pstm.setInt(4,cadastro.getRg());
			pstm.setString(5,cadastro.getDataCompra());
			pstm.setString(6, cadastro.getTipocompra());
			pstm.setInt(7,cadastro.getCpf());
			pstm.setString(8,cadastro.getEstado());
			pstm.setString(9,cadastro.getCidade());
			
			pstm.execute();
			
			System.out.println("cadastro inserido com sucesso!!!");
			
			conn.close();
			pstm.close();
			
			
		}catch (Exception ex){
			System.out.println(ex.getMessage());
		}
		
		}
	public void updade() {
		Scanner sc = new Scanner(System.in);
		Cadastro cadastro = new Cadastro();
		
		System.out.println("digite seu id");
		cadastro.setId(sc.nextInt());
		
		System.out.println("digite seu Nome");
		cadastro.setNome( sc.next());
		
		System.out.println("digite seu Telefone");
		cadastro.setTelefone(sc.nextInt());
		
		System.out.println("digite seu Email");
		cadastro.setEmail(sc.next());
		
		System.out.println("digite seu Rg");
		cadastro.setRg(sc.nextInt());
		
		System.out.println("digite  Data da compra");
		cadastro.setDataCompra(sc.next());
		
		System.out.println("digite  Tipo de compra");
		cadastro.setTipocompra(sc.next());
		
		System.out.println("digite seu cpf");
		cadastro.setCpf(sc.nextInt());
		
		System.out.println("digite seu estado");
		cadastro.setEstado(sc.next());
		
		System.out.println("digite seu cidade");
		cadastro.setCidade(sc.next());
		
		
		String sql = "UPDATE  cadastro set  nome = ?, telefone = ?, email = ?, rg = ?, dataCompra = ?, tipoCompra = ?, cpf = ?,  estado = ?, cidade = ? where id = ? ";
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConexaoBanco.createConnection();
			pstm = conn.prepareStatement(sql);
			
			
			pstm.setString(1,cadastro.getNome());
			pstm.setInt(2,cadastro.getTelefone());
			pstm.setString(3,cadastro.getEmail());
			pstm.setInt(4,cadastro.getRg());
			pstm.setString(5,cadastro.getDataCompra());
			pstm.setString(6, cadastro.getTipocompra());
			pstm.setInt(7,cadastro.getCpf());
			pstm.setString(8,cadastro.getEstado());
			pstm.setString(9,cadastro.getCidade());
			pstm.setInt(10,cadastro.getId());
			
			pstm.execute();
			
			System.out.println("cadastro atualizado com sucesso!!!");
			
			conn.close();
			pstm.close();
			
			
		}catch (Exception ex){
			System.out.println(ex.getMessage());
		}
		
		}
	
	public void delete() {
		Scanner sc = new Scanner(System.in);
		Cadastro cadastro = new Cadastro();
		
		System.out.println("digite seu id");
		cadastro.setId(sc.nextInt());
		
		System.out.println("digite seu Nome");
		cadastro.setNome( sc.next());
		
		System.out.println("digite seu Telefone");
		cadastro.setTelefone(sc.nextInt());
		
		System.out.println("digite seu Email");
		cadastro.setEmail(sc.next());
		
		System.out.println("digite seu Rg");
		cadastro.setRg(sc.nextInt());
		
		System.out.println("digite  Data da compra");
		cadastro.setDataCompra(sc.next());
		
		System.out.println("digite  Tipo de compra");
		cadastro.setTipocompra(sc.next());
		
		System.out.println("digite seu cpf");
		cadastro.setCpf(sc.nextInt());
		
		System.out.println("digite seu estado");
		cadastro.setEstado(sc.next());
		
		System.out.println("digite seu cidade");
		cadastro.setCidade(sc.next());
		
	
		String sql = "DELETE  cadastro set  nome = ?, telefone = ?, email = ?, rg = ?, dataCompra = ?, tipoCompra = ?, cpf = ?,  estado = ?, cidade = ? where id = ? ";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		try {
			conn = ConexaoBanco.createConnection();
			pstm = conn.prepareStatement(sql);
			
			
			pstm.setString(1,cadastro.getNome());
			pstm.setInt(2,cadastro.getTelefone());
			pstm.setString(3,cadastro.getEmail());
			pstm.setInt(4,cadastro.getRg());
			pstm.setString(5,cadastro.getDataCompra());
			pstm.setString(6, cadastro.getTipocompra());
			pstm.setInt(7,cadastro.getCpf());
			pstm.setString(8,cadastro.getEstado());
			pstm.setString(9,cadastro.getCidade());
			pstm.setInt(10,cadastro.getId());
			
			pstm.execute();
			
			System.out.println("cadastro deletado com sucesso!!!");
			
			conn.close();
			pstm.close();
			
			
		}catch (Exception ex){
			System.out.println(ex.getMessage());
		}
		
		}
		
	}
		
	
	

