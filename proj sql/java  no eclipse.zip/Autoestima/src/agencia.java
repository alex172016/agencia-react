

import java.util.Scanner;
import model.Cadastro;


public class agencia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		boolean repetir =true;
		do {
			System.out.println("digite uma op��o abaixo");
			System.out.println("0 - Sair");
			System.out.println("1 - Cadastro");
			
		
			int opcao = sc.nextInt();
			Cadastro cadastro = new Cadastro();
			switch(opcao) {
			
			case 0:
			repetir = false;
			break;
			
			case 1:
				cadastro.menu();
			break;
			
		
			default:
			System.out.println("op��o invalida");
			break;
			
			}
			
		}while(repetir);

}
}