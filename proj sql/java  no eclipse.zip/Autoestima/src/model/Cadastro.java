package model;

import java.util.Scanner;

import service.CadastroService;

public class Cadastro {

public Cadastro() {
	// TODO Auto-generated constructor stub
}
private Integer id;
private String nome;
private Integer telefone;
private String email;
private Integer rg;
private String dataCompra;
private String tipocompra;
private Integer cpf;
private String estado;
private String cidade;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public Integer getTelefone() {
	return telefone;
}
public void setTelefone(Integer telefone) {
	this.telefone = telefone;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Integer getRg() {
	return rg;
}
public void setRg(Integer rg) {
	this.rg = rg;
}
public String getDataCompra() {
	return dataCompra;
}
public void setDataCompra(String dataCompra) {
	this.dataCompra = dataCompra;
}
public String getTipocompra() {
	return tipocompra;
}
public void setTipocompra(String tipocompra) {
	this.tipocompra = tipocompra;
}
public Integer getCpf() {
	return cpf;
}
public void setCpf(Integer cpf) {
	this.cpf = cpf;
}
public String getEstado() {
	return estado;
}
public void setEstado(String estado) {
	this.estado = estado;
}
public String getCidade() {
	return cidade;
}
public void setCidade(String cidade) {
	this.cidade = cidade;
}
public Cadastro(Integer id, String nome, Integer telefone, String email, Integer rg, String dataCompra,
		String tipocompra, Integer cpf, String estado, String cidade) {
	super();
	this.id = id;
	this.nome = nome;
	this.telefone = telefone;
	this.email = email;
	this.rg = rg;
	this.dataCompra = dataCompra;
	this.tipocompra = tipocompra;
	this.cpf = cpf;
	this.estado = estado;
	this.cidade = cidade;
}

public void menu() {
	Scanner sc = new Scanner (System.in);
	boolean repetir =true;
	do {
		System.out.println("digite uma op��o abaixo");
		System.out.println("0 - Sair");
		System.out.println("1 - Cadastro");
		System.out.println("2 - alterar cadastro");
		System.out.println("3 - excluir cadastro");
	
		int opcao = sc.nextInt();
		CadastroService cadastroService = new CadastroService();
		
		switch(opcao) {
		case 0:
		repetir = false;
		break;
		
		case 1:
			cadastroService.save();
		break;
		
		case 2:
			cadastroService.updade();
		break;
		
		case 3:
			cadastroService.delete();
		break;
		default:
		System.out.println("op��o invalida");
		break;
		
		}
		
	}while(repetir);

}
}


